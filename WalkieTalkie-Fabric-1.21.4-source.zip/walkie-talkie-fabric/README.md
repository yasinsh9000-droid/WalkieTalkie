# Walkie-Talkie (Fabric, Minecraft Java 1.21.4)

Port of the Bedrock walkie-talkie add-on.

* **Walkie-Talkie** (right-click): opens a green **WALKIE-OS** screen inside a yellow walkie-talkie body.
  First use: register a name + a password for your walkie-talkie. Later uses ask for the password,
  then show your name and rank. You can change your password / name from the screen.
* **Manager Card** (right-click): you become a Game Manager and a separate purple **manager computer**
  opens. It lists every registered walkie-talkie; you can accept a player as **Villager** or **William**,
  change or remove a rank, reject a request, reset a password or delete the data.
* Ranks give the tag `wt_villager` / `wt_william` and a name prefix (with a small icon) above the head,
  in the tab list and in chat. The purple icon with white eyes is William.
* Everything is touch friendly: tap a line / button. Drag or use the mouse wheel to scroll.

Get the items from the creative inventory (Tools & Utilities tab) or:

    /give @s walkie_talkie:walkie_talkie
    /give @s walkie_talkie:manager_card

To remove a manager: stop the server and delete that player's UUID from `managers`
in `walkie_talkie.json` (world folder).

## Settings

`config/walkie_talkie.json` (created on first start): `showPasswordToManager` (default false),
name/password length limits and the number of password tries.

## Saved data

`<world folder>/walkie_talkie.json` (players, passwords, ranks, managers).
The mod must be installed on the server **and** on every client.

## Build the jar

Needs JDK 21 and Gradle 8.12 or newer (the Gradle wrapper is not included):

    gradle build

The jar is `build/libs/walkie-talkie-1.0.0.jar`. Put it in the `mods` folder together with
**Fabric Loader 0.16.10+** and **Fabric API for 1.21.4**.

### Without installing anything: GitHub Actions

1. Create a new (private) GitHub repository.
2. Upload the contents of this folder (including the hidden `.github` folder).
3. Open the **Actions** tab -> the **build** workflow -> when it is green, download the
   `walkie-talkie-fabric-1.21.4` artifact. The jar is inside.
