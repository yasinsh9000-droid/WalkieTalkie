package net.walkietalkie.net;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.walkietalkie.WalkieTalkieMod;

/** Client -> server: "the player pressed this" (a JSON document). */
public record ActionC2S(String json) implements CustomPayload {
    public static final CustomPayload.Id<ActionC2S> ID =
            new CustomPayload.Id<>(Identifier.of(WalkieTalkieMod.MOD_ID, "action"));
    public static final PacketCodec<RegistryByteBuf, ActionC2S> CODEC =
            PacketCodec.tuple(PacketCodecs.STRING, ActionC2S::json, ActionC2S::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
