package net.walkietalkie.net;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.walkietalkie.WalkieTalkieMod;

/** Server -> client: "show this page" (a JSON document). */
public record ScreenS2C(String json) implements CustomPayload {
    public static final CustomPayload.Id<ScreenS2C> ID =
            new CustomPayload.Id<>(Identifier.of(WalkieTalkieMod.MOD_ID, "screen"));
    public static final PacketCodec<RegistryByteBuf, ScreenS2C> CODEC =
            PacketCodec.tuple(PacketCodecs.STRING, ScreenS2C::json, ScreenS2C::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
