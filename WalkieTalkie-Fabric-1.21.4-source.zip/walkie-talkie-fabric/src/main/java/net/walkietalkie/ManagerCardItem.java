package net.walkietalkie;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** The manager card: right-click makes you a Game Manager and opens the manager computer. */
public class ManagerCardItem extends Item {
    public ManagerCardItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (!world.isClient() && user instanceof ServerPlayerEntity player) {
            WalkieServer.openCard(player);
        }
        return ActionResult.SUCCESS;
    }
}
