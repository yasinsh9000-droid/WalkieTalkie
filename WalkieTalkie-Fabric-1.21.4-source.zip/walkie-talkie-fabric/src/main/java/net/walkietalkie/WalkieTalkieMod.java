package net.walkietalkie;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.walkietalkie.net.ActionC2S;
import net.walkietalkie.net.ScreenS2C;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WalkieTalkieMod implements ModInitializer {
    public static final String MOD_ID = "walkie_talkie";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        WalkieConfig.load();
        ModItems.init();

        PayloadTypeRegistry.playS2C().register(ScreenS2C.ID, ScreenS2C.CODEC);
        PayloadTypeRegistry.playC2S().register(ActionC2S.ID, ActionC2S.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ActionC2S.ID, (payload, context) -> {
            var player = context.player();
            String json = payload.json();
            WalkieServer.runOnServer(() -> WalkieServer.handle(player, json));
        });

        ServerLifecycleEvents.SERVER_STARTED.register(WalkieServer::onStart);
        ServerLifecycleEvents.SERVER_STOPPING.register(WalkieServer::onStop);
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> WalkieServer.onJoin(handler.player));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> WalkieServer.onLeave(handler.player));
    }
}
