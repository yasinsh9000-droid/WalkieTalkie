package net.walkietalkie;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.WorldSavePath;
import net.walkietalkie.data.Entry;
import net.walkietalkie.data.WalkieData;
import net.walkietalkie.net.ScreenS2C;

/** All server-side logic: storage, passwords, ranks, manager actions. */
public final class WalkieServer {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static MinecraftServer server;
    private static Path file;
    private static WalkieData data = new WalkieData();
    /** Players who typed the right password while their walkie screen is open. */
    private static final Set<UUID> unlocked = new HashSet<>();
    private static final Map<UUID, Integer> failures = new HashMap<>();

    private WalkieServer() {}

    /* ------------------------------ lifecycle ------------------------------ */

    public static void onStart(MinecraftServer s) {
        server = s;
        file = s.getSavePath(WorldSavePath.ROOT).resolve("walkie_talkie.json");
        data = new WalkieData();
        try {
            if (Files.exists(file)) {
                WalkieData loaded = GSON.fromJson(Files.readString(file), WalkieData.class);
                if (loaded != null) data = loaded;
            }
        } catch (Exception e) {
            WalkieTalkieMod.LOGGER.error("Could not read walkie_talkie.json", e);
        }
        if (data.entries == null) data.entries = new LinkedHashMap<>();
        if (data.managers == null) data.managers = new LinkedHashSet<>();
    }

    public static void onStop(MinecraftServer s) {
        save();
        unlocked.clear();
        failures.clear();
        server = null;
    }

    public static void onJoin(ServerPlayerEntity player) {
        Entry e = data.entries.get(player.getUuid().toString());
        if (e != null && !e.rank.isEmpty()) applyRank(player, Rank.of(e.rank));
    }

    public static void onLeave(ServerPlayerEntity player) {
        unlocked.remove(player.getUuid());
        failures.remove(player.getUuid());
    }

    private static void save() {
        if (file == null) return;
        try {
            Files.writeString(file, GSON.toJson(data));
        } catch (IOException e) {
            WalkieTalkieMod.LOGGER.error("Could not save walkie_talkie.json", e);
        }
    }

    /** Makes sure the work happens on the server thread. */
    public static void runOnServer(Runnable task) {
        if (server != null) server.execute(task);
    }

    /* ------------------------------ item entry ------------------------------ */

    public static void openWalkie(ServerPlayerEntity player) {
        if (server == null) return;
        UUID uuid = player.getUuid();
        unlocked.remove(uuid);
        failures.remove(uuid);
        Entry e = data.entries.get(uuid.toString());
        send(player, page("walkie", e == null ? "welcome" : "lock"));
    }

    public static void openCard(ServerPlayerEntity player) {
        if (server == null) return;
        if (data.managers.add(player.getUuid().toString())) {
            save();
            player.sendMessage(Text.literal("You are now a Game Manager.").formatted(Formatting.LIGHT_PURPLE), false);
        }
        send(player, managerPage(null));
    }

    /* ------------------------------ packets ------------------------------ */

    public static void handle(ServerPlayerEntity player, String json) {
        if (server == null) return;
        JsonObject msg;
        try {
            msg = JsonParser.parseString(json).getAsJsonObject();
        } catch (Exception e) {
            return;
        }
        String action = str(msg, "a");
        try {
            switch (action) {
                case "close" -> unlocked.remove(player.getUuid());
                case "register" -> register(player, msg);
                case "unlock" -> unlock(player, msg);
                case "status" -> {
                    if (unlocked.contains(player.getUuid())) sendStatus(player, null);
                }
                case "change_pass", "change_name" -> changeField(player, action, msg);
                case "resend" -> resend(player);
                default -> {
                    if (action.startsWith("m_")) managerAction(player, action, msg);
                }
            }
        } catch (Exception e) {
            WalkieTalkieMod.LOGGER.warn("Walkie action '{}' failed: {}", action, e.toString());
        }
    }

    private static void register(ServerPlayerEntity player, JsonObject msg) {
        String id = player.getUuid().toString();
        if (data.entries.containsKey(id)) {
            openWalkie(player);
            return;
        }
        String name = str(msg, "name").trim();
        String pass = str(msg, "pass").trim();
        String err = validateName(name);
        if (err == null) err = validatePass(pass);
        if (err != null) {
            send(player, info("walkie", err));
            return;
        }
        Entry e = new Entry();
        e.id = id;
        e.gamertag = player.getName().getString();
        e.name = name;
        e.pass = pass;
        e.status = "pending";
        e.rank = "";
        data.entries.put(id, e);
        save();
        notifyManagers(e);
        send(player, info("walkie", "REQUEST SENT.", "WAIT FOR A MANAGER TO", "ACCEPT YOUR RANK."));
    }

    private static void unlock(ServerPlayerEntity player, JsonObject msg) {
        UUID uuid = player.getUuid();
        Entry e = data.entries.get(uuid.toString());
        if (e == null) {
            openWalkie(player);
            return;
        }
        int fails = failures.getOrDefault(uuid, 0);
        if (fails >= WalkieConfig.maxPasswordTries) {
            send(player, info("walkie", "TOO MANY WRONG PASSWORDS.", "CLOSE AND TRY AGAIN LATER."));
            return;
        }
        if (e.pass.equals(str(msg, "pass"))) {
            unlocked.add(uuid);
            failures.remove(uuid);
            sendStatus(player, null);
        } else {
            failures.put(uuid, fails + 1);
            JsonObject p = page("walkie", "lock");
            p.addProperty("msg", "WRONG PASSWORD.");
            send(player, p);
        }
    }

    private static void changeField(ServerPlayerEntity player, String action, JsonObject msg) {
        UUID uuid = player.getUuid();
        Entry e = data.entries.get(uuid.toString());
        if (e == null || !unlocked.contains(uuid)) return;
        String value = str(msg, "value").trim();
        boolean isPass = action.equals("change_pass");
        String err = isPass ? validatePass(value) : validateName(value);
        if (err != null) {
            sendStatus(player, err);
            return;
        }
        if (isPass) e.pass = value;
        else e.name = value;
        save();
        sendStatus(player, isPass ? "PASSWORD CHANGED." : "NAME CHANGED.");
    }

    private static void resend(ServerPlayerEntity player) {
        UUID uuid = player.getUuid();
        Entry e = data.entries.get(uuid.toString());
        if (e == null || !unlocked.contains(uuid)) return;
        if (e.rank.isEmpty() && e.status.equals("rejected")) {
            e.status = "pending";
            save();
            notifyManagers(e);
            send(player, info("walkie", "REQUEST SENT AGAIN."));
        } else {
            sendStatus(player, null);
        }
    }

    /* ------------------------------ manager ------------------------------ */

    private static void managerAction(ServerPlayerEntity player, String action, JsonObject msg) {
        if (!data.managers.contains(player.getUuid().toString())) return;
        Entry e = data.entries.get(str(msg, "id"));
        String note = null;
        switch (action) {
            case "m_give" -> {
                Rank r = Rank.of(str(msg, "rank"));
                if (e != null && r != null) {
                    e.rank = r.key;
                    e.status = "approved";
                    save();
                    applyToOnline(e, r);
                    tell(e, Text.literal("A manager accepted your request. Your rank: " + r.label + ".").formatted(r.color));
                    note = e.name + " IS NOW " + r.label.toUpperCase(Locale.ROOT) + ".";
                }
            }
            case "m_remove", "m_reject" -> {
                if (e != null) {
                    boolean reject = action.equals("m_reject");
                    e.rank = "";
                    e.status = reject ? "rejected" : "pending";
                    save();
                    applyToOnline(e, null);
                    tell(e, Text.literal(reject ? "A manager rejected your rank request." : "A manager removed your rank.")
                            .formatted(reject ? Formatting.RED : Formatting.YELLOW));
                    note = reject ? "REJECTED " + e.name + "." : "RANK REMOVED FROM " + e.name + ".";
                }
            }
            case "m_reset" -> {
                if (e != null) {
                    String pass = str(msg, "pass").trim();
                    String err = validatePass(pass);
                    if (err == null) {
                        e.pass = pass;
                        save();
                        note = "PASSWORD RESET FOR " + e.name + ".";
                    } else {
                        note = err;
                    }
                }
            }
            case "m_delete" -> {
                if (e != null) {
                    data.entries.remove(e.id);
                    save();
                    applyToOnline(e, null);
                    tell(e, Text.literal("Your walkie-talkie data was deleted. Use your walkie-talkie to register again.")
                            .formatted(Formatting.YELLOW));
                    note = "DELETED " + e.name + ".";
                }
            }
            default -> {
                // m_list: just refresh
            }
        }
        send(player, managerPage(note));
    }

    private static int weight(Entry e) {
        if (e.rank.isEmpty() && !e.status.equals("rejected")) return 0;
        if (e.rank.equals("villager")) return 1;
        if (e.rank.equals("william")) return 2;
        return 3;
    }

    private static JsonObject managerPage(String note) {
        JsonObject p = page("manager", "manager");
        List<Entry> list = new ArrayList<>(data.entries.values());
        list.sort(Comparator.comparingInt(WalkieServer::weight).thenComparing(x -> x.name.toLowerCase(Locale.ROOT)));
        JsonArray arr = new JsonArray();
        for (Entry e : list) {
            JsonObject o = new JsonObject();
            o.addProperty("id", e.id);
            o.addProperty("name", e.name);
            o.addProperty("gamertag", e.gamertag);
            o.addProperty("rank", e.rank);
            o.addProperty("status", e.status);
            o.addProperty("online", onlinePlayer(e.id) != null);
            if (WalkieConfig.showPasswordToManager) o.addProperty("pass", e.pass);
            arr.add(o);
        }
        p.add("entries", arr);
        p.addProperty("showPass", WalkieConfig.showPasswordToManager);
        if (note != null) p.addProperty("msg", note);
        return p;
    }

    /* ------------------------------ ranks ------------------------------ */

    private static ServerPlayerEntity onlinePlayer(String id) {
        try {
            return server.getPlayerManager().getPlayer(UUID.fromString(id));
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    private static void applyToOnline(Entry e, Rank rank) {
        ServerPlayerEntity p = onlinePlayer(e.id);
        if (p != null) applyRank(p, rank);
    }

    private static void tell(Entry e, Text text) {
        ServerPlayerEntity p = onlinePlayer(e.id);
        if (p != null) p.sendMessage(text, false);
    }

    /** Gives the rank tag and the "[icon] [Rank]" name prefix (null rank = remove both). */
    private static void applyRank(ServerPlayerEntity player, Rank rank) {
        Scoreboard sb = server.getScoreboard();
        String holder = player.getNameForScoreboard();
        for (Rank r : Rank.values()) {
            player.removeCommandTag(r.tag);
            Team t = sb.getTeam(r.tag);
            if (t != null && sb.getScoreHolderTeam(holder) == t) sb.removeScoreHolderFromTeam(holder, t);
        }
        if (rank != null) {
            player.addCommandTag(rank.tag);
            Team t = sb.getTeam(rank.tag);
            if (t == null) t = sb.addTeam(rank.tag);
            t.setPrefix(rank.prefix());
            sb.addScoreHolderToTeam(holder, t);
        }
    }

    private static void notifyManagers(Entry e) {
        Text text = Text.literal("[Walkie] " + e.name + " (" + e.gamertag + ") requested a rank.").formatted(Formatting.YELLOW);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (data.managers.contains(p.getUuid().toString()) && !p.getUuid().toString().equals(e.id)) {
                p.sendMessage(text, false);
            }
        }
    }

    /* ------------------------------ helpers ------------------------------ */

    private static void sendStatus(ServerPlayerEntity player, String note) {
        Entry e = data.entries.get(player.getUuid().toString());
        if (e == null) {
            openWalkie(player);
            return;
        }
        JsonObject p = page("walkie", "status");
        p.addProperty("name", e.name);
        p.addProperty("rank", e.rank);
        p.addProperty("status", e.status);
        if (note != null) p.addProperty("msg", note);
        send(player, p);
    }

    private static JsonObject page(String target, String page) {
        JsonObject o = new JsonObject();
        o.addProperty("target", target);
        o.addProperty("page", page);
        return o;
    }

    private static JsonObject info(String target, String... lines) {
        JsonObject o = page(target, "info");
        JsonArray arr = new JsonArray();
        for (String l : lines) arr.add(l);
        o.add("lines", arr);
        return o;
    }

    private static void send(ServerPlayerEntity player, JsonObject o) {
        ServerPlayNetworking.send(player, new ScreenS2C(o.toString()));
    }

    private static String str(JsonObject o, String key) {
        return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : "";
    }

    private static String validateName(String name) {
        if (name.length() < WalkieConfig.nameMin || name.length() > WalkieConfig.nameMax) {
            return "NAME MUST BE " + WalkieConfig.nameMin + "-" + WalkieConfig.nameMax + " CHARACTERS.";
        }
        return null;
    }

    private static String validatePass(String pass) {
        if (pass.length() < WalkieConfig.passMin || pass.length() > WalkieConfig.passMax) {
            return "PASSWORD MUST BE " + WalkieConfig.passMin + "-" + WalkieConfig.passMax + " CHARACTERS.";
        }
        return null;
    }
}
