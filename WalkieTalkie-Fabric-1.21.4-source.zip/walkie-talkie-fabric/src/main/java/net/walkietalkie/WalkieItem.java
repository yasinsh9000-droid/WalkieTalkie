package net.walkietalkie;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** The walkie-talkie: right-click opens the green WALKIE-OS screen. */
public class WalkieItem extends Item {
    public WalkieItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (!world.isClient() && user instanceof ServerPlayerEntity player) {
            WalkieServer.openWalkie(player);
        }
        return ActionResult.SUCCESS;
    }
}
