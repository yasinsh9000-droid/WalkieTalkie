package net.walkietalkie.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.walkietalkie.net.ScreenS2C;

public class WalkieTalkieClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(ScreenS2C.ID, (payload, context) -> {
            MinecraftClient client = context.client();
            String json = payload.json();
            client.execute(() -> show(client, json));
        });
    }

    private static void show(MinecraftClient client, String json) {
        JsonObject o;
        try {
            o = JsonParser.parseString(json).getAsJsonObject();
        } catch (Exception e) {
            return;
        }
        String target = o.has("target") ? o.get("target").getAsString() : "walkie";
        Screen current = client.currentScreen;
        if (target.equals("manager")) {
            if (current instanceof ManagerScreen m) m.apply(o);
            else client.setScreen(new ManagerScreen(o));
        } else {
            if (current instanceof WalkieScreen w) w.apply(o);
            else client.setScreen(new WalkieScreen(o));
        }
    }
}
