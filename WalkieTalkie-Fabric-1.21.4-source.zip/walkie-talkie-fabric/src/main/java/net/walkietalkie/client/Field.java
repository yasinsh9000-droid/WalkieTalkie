package net.walkietalkie.client;

/** A text box the player types into (drawn by the screens themselves). */
final class Field {
    final String label;
    final boolean secret;
    final int max;
    final StringBuilder text = new StringBuilder();

    Field(String label, boolean secret, int max, String initial) {
        this.label = label;
        this.secret = secret;
        this.max = max;
        this.text.append(initial);
    }

    String shown() {
        return secret ? "*".repeat(text.length()) : text.toString();
    }

    String value() {
        return text.toString().trim();
    }
}
