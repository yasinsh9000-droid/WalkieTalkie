package net.walkietalkie.client;

import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.walkietalkie.net.ActionC2S;

/**
 * Shared behaviour of both screens: touch/mouse presses, drag-scrolling, mouse wheel,
 * typing into text boxes, and sending actions to the server.
 */
abstract class TermScreen extends Screen {
    protected record Hit(String id, int x, int y, int w, int h, Runnable action) {}

    protected final List<Hit> hits = new ArrayList<>();
    protected final List<Field> fields = new ArrayList<>();
    protected int active = 0;
    protected float scroll = 0;
    protected int maxScroll = 0;
    /** The scrollable area (set by the subclass while drawing). */
    protected int vpX;
    protected int vpY;
    protected int vpW;
    protected int vpH;

    private String pressedId;
    private double pressX;
    private double pressY;
    private boolean dragged;

    protected TermScreen(String title) {
        super(Text.literal(title));
    }

    protected abstract void drawScreen(DrawContext ctx, int mouseX, int mouseY);

    /** Enter pressed in the last text box. */
    protected abstract void submit();

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        hits.clear();
        drawScreen(context, mouseX, mouseY);
        scroll = Math.max(0, Math.min(scroll, maxScroll));
    }

    /* ------------------------------ server ------------------------------ */

    protected static JsonObject action(String name) {
        JsonObject o = new JsonObject();
        o.addProperty("a", name);
        return o;
    }

    protected static String str(JsonObject o, String key) {
        return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : "";
    }

    protected void send(JsonObject o) {
        ClientPlayNetworking.send(new ActionC2S(o.toString()));
    }

    @Override
    public void removed() {
        try {
            send(action("close"));
        } catch (Exception ignored) {
            // not connected any more
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    /* ------------------------------ input ------------------------------ */

    protected Hit hitAt(double mx, double my) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (Gfx.inside(mx, my, h.x(), h.y(), h.w(), h.h())) return h;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        Hit h = hitAt(mouseX, mouseY);
        pressedId = h == null ? null : h.id();
        pressX = mouseX;
        pressY = mouseY;
        dragged = false;
        return true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (Math.abs(mouseY - pressY) > 4 || Math.abs(mouseX - pressX) > 4) dragged = true;
        if (dragged && maxScroll > 0 && Gfx.inside(pressX, pressY, vpX, vpY, vpW, vpH)) {
            scroll = Math.max(0, Math.min(scroll - (float) deltaY, maxScroll));
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && !dragged && pressedId != null) {
            Hit h = hitAt(mouseX, mouseY);
            if (h != null && h.id().equals(pressedId)) h.action().run();
        }
        pressedId = null;
        dragged = false;
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (maxScroll > 0) {
            scroll = Math.max(0, Math.min(scroll - (float) (verticalAmount * 12), maxScroll));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (!fields.isEmpty() && chr >= 32 && chr != 127) {
            Field f = fields.get(Math.min(active, fields.size() - 1));
            if (f.text.length() < f.max) f.text.append(chr);
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!fields.isEmpty()) {
            Field f = fields.get(Math.min(active, fields.size() - 1));
            if (keyCode == 259) { // backspace
                if (f.text.length() > 0) f.text.deleteCharAt(f.text.length() - 1);
                return true;
            }
            if (keyCode == 257 || keyCode == 335) { // enter
                if (active < fields.size() - 1) active++;
                else submit();
                return true;
            }
            if (keyCode == 258) { // tab
                active = (active + 1) % fields.size();
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
