package net.walkietalkie.client;

import net.minecraft.client.gui.DrawContext;

/** A small pixel-art picture drawn with filled rectangles (no texture files needed). */
final class Sprite {
    /** The purple guy with white eyes (William rank). */
    static final Sprite WILLIAM = new Sprite(new String[] {
        "................",
        ".....oooooo.....",
        "....oPPPPPPo....",
        "...oPPLLPPPPo...",
        "...oPPwPPwPPo...",
        "...oPPwPPwPPo...",
        "...oPPPPPPPPo...",
        "....oPPDDPPo....",
        ".....oooooo.....",
        "...ooDPPPPDoo...",
        "..oPPDPPPPDPPo..",
        "..oPPoDPPDoPPo..",
        "..oPPoDPPDoPPo..",
        "...oo.oPPo.oo...",
        ".....oDPoPDo....",
        ".....ooo.ooo....",
    }, ".oPDwL", new int[] {0, 0xFF12081C, 0xFF8E44AD, 0xFF6C3483, 0xFFFFFFFF, 0xFFB066CD});

    static final Sprite VILLAGER = new Sprite(new String[] {
        "................",
        "....oooooooo....",
        "...oBBBBBBBBo...",
        "...oBTTTTTTBo...",
        "...oTTTTTTTTo...",
        "...obbbbbbbbo...",
        "...oTeTTTTeTo...",
        "...oTTTnnTTTo...",
        "...oTTTnnTTTo...",
        "....oTTTTTTo....",
        "..ooGGGGGGGGoo..",
        ".oGGGGggggGGGGo.",
        ".oGGoGGGGGGoGGo.",
        ".oGGoGGGGGGoGGo.",
        "..ooGGGGGGGGoo..",
        "....oo....oo....",
    }, ".oBTnbeGg", new int[] {0, 0xFF23160E, 0xFF5C4028, 0xFFC9A07A, 0xFFA57858, 0xFF3C2818, 0xFF28964A, 0xFF785C3A, 0xFF5E462A});

    /** Little yellow walkie-talkie (used for "pending" rows). */
    static final Sprite WALKIE = new Sprite(new String[] {
        "..b.........",
        "..b.........",
        "..b.........",
        ".oooooooooo.",
        ".oYYYYYYYYo.",
        ".oYooooooYo.",
        ".oYoGGGGoYo.",
        ".oYooooooYo.",
        ".oYYYYYYYYo.",
        ".oYoKKKKoYo.",
        ".oYoKKKKoYo.",
        ".oYoKKKKoYo.",
        ".oYYYYYYYYo.",
        ".oYYYYYYYYo.",
        ".oYYYYYYYYo.",
        "..oooooooo..",
    }, ".boYGK", new int[] {0, 0xFF101010, 0xFF2A2008, 0xFFE2AB1C, 0xFF6A8A2A, 0xFF26262A});

    private final String[] rows;
    private final String keys;
    private final int[] colors;
    final int w;
    final int h;

    private Sprite(String[] rows, String keys, int[] colors) {
        this.rows = rows;
        this.keys = keys;
        this.colors = colors;
        this.h = rows.length;
        this.w = rows[0].length();
    }

    void draw(DrawContext c, int x, int y, int scale) {
        for (int j = 0; j < rows.length; j++) {
            String r = rows[j];
            for (int i = 0; i < r.length(); i++) {
                int idx = keys.indexOf(r.charAt(i));
                if (idx > 0) {
                    c.fill(x + i * scale, y + j * scale, x + (i + 1) * scale, y + (j + 1) * scale, colors[idx]);
                }
            }
        }
    }
}
