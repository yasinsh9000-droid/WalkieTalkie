package net.walkietalkie.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import net.minecraft.client.gui.DrawContext;

/**
 * The manager card's screen: a purple "computer" with a player list on the left
 * and the selected player's details + buttons on the right.
 * (Deliberately looks different from the green walkie-talkie screen.)
 */
final class ManagerScreen extends TermScreen {
    private static final int TEXT = 0xFFFFFFFF;
    private static final int SOFT = 0xFFB79CFF;
    private static final int DIMTXT = 0xFF8A7FB0;
    private static final int PANEL = 0xFF17122F;
    private static final int PANEL_LINE = 0xFF3B2A73;

    private JsonArray entries = new JsonArray();
    private boolean showPass;
    private String message = "";
    private String selectedId = "";
    private boolean resetMode;
    private boolean confirmDelete;

    private DrawContext cx;
    private int cmx;
    private int cmy;

    ManagerScreen(JsonObject first) {
        super("Manager");
        apply(first);
    }

    /** A fresh list arrived from the server. */
    void apply(JsonObject o) {
        entries = o.has("entries") ? o.getAsJsonArray("entries") : new JsonArray();
        showPass = o.has("showPass") && o.get("showPass").getAsBoolean();
        message = str(o, "msg");
        if (find(selectedId) == null) selectedId = "";
        resetMode = false;
        confirmDelete = false;
        fields.clear();
        active = 0;
    }

    private JsonObject find(String id) {
        for (int i = 0; i < entries.size(); i++) {
            JsonObject e = entries.get(i).getAsJsonObject();
            if (str(e, "id").equals(id)) return e;
        }
        return null;
    }

    private void select(String id) {
        selectedId = id;
        resetMode = false;
        confirmDelete = false;
        fields.clear();
        active = 0;
    }

    /* ------------------------------ actions ------------------------------ */

    private void give(String rank) {
        JsonObject o = action("m_give");
        o.addProperty("id", selectedId);
        o.addProperty("rank", rank);
        send(o);
    }

    private void manage(String name) {
        JsonObject o = action(name);
        o.addProperty("id", selectedId);
        send(o);
    }

    private void startReset() {
        resetMode = true;
        confirmDelete = false;
        fields.clear();
        fields.add(new Field("> NEW PASSWORD FOR THIS PLAYER", true, 16, ""));
        active = 0;
    }

    private void deleteClick() {
        if (confirmDelete) manage("m_delete");
        else confirmDelete = true;
    }

    @Override
    protected void submit() {
        if (resetMode && !fields.isEmpty()) {
            String p = fields.get(0).value();
            if (p.length() < 3 || p.length() > 16) {
                message = "PASSWORD MUST BE 3-16 CHARACTERS.";
                return;
            }
            JsonObject o = action("m_reset");
            o.addProperty("id", selectedId);
            o.addProperty("pass", p);
            send(o);
        }
    }

    /* ------------------------------ drawing ------------------------------ */

    @Override
    protected void drawScreen(DrawContext ctx, int mx, int my) {
        cx = ctx;
        cmx = mx;
        cmy = my;
        ctx.fill(0, 0, width, height, 0xB0000000);

        int dw = Math.min(width - 8, 470);
        int dh = Math.min(height - 6, 244);
        int dx = (width - dw) / 2;
        int dy = (height - dh) / 2;

        // grey monitor
        Gfx.rect(ctx, dx, dy, dw, dh, 0xFF101014);
        Gfx.rect(ctx, dx + 1, dy + 1, dw - 2, dh - 2, 0xFF3E3E4A);
        Gfx.rect(ctx, dx + 3, dy + 3, dw - 6, dh - 6, 0xFF24242E);
        int sx = dx + 6;
        int sy = dy + 6;
        int sw = dw - 12;
        int sh = dh - 12;
        Gfx.rect(ctx, sx, sy, sw, sh, 0xFF110D24);

        // title bar
        Gfx.rect(ctx, sx, sy, sw, 16, 0xFF5B2D91);
        Sprite.WILLIAM.draw(ctx, sx + 2, sy, 1);
        text("MANAGER TERMINAL", sx + 22, sy + 4, TEXT);
        int closeW = 18;
        int closeX = sx + sw - closeW - 2;
        boolean closeHover = Gfx.inside(mx, my, closeX, sy + 2, closeW, 12);
        Gfx.rect(ctx, closeX, sy + 2, closeW, 12, closeHover ? 0xFFFF6B6B : 0xFFC0392B);
        text("X", closeX + 6, sy + 4, TEXT);
        hits.add(new Hit("close", closeX, sy + 2, closeW, 12, this::close));

        // status bar
        int barH = 12;
        int barY = sy + sh - barH;
        Gfx.rect(ctx, sx, barY, sw, barH, 0xFF1C1538);
        int pending = 0;
        for (int i = 0; i < entries.size(); i++) {
            JsonObject e = entries.get(i).getAsJsonObject();
            if (str(e, "rank").isEmpty() && !str(e, "status").equals("rejected")) pending++;
        }
        text("WALKIE-TALKIES: " + entries.size() + "   WAITING: " + pending, sx + 4, barY + 2, DIMTXT);
        if (!message.isEmpty()) {
            int mw = textRenderer.getWidth(message);
            text(message, sx + sw - mw - 4, barY + 2, 0xFFFFD36B);
        }

        int bodyY = sy + 18;
        int bodyH = barY - bodyY - 2;
        int lw = Math.max(140, sw * 4 / 10);
        drawList(sx + 2, bodyY, lw, bodyH, mx, my);
        drawDetails(sx + lw + 6, bodyY, sw - lw - 8, bodyH);
    }

    private void drawList(int x, int y, int w, int h, int mx, int my) {
        Gfx.rect(cx, x, y, w, h, PANEL);
        Gfx.border(cx, x, y, w, h, PANEL_LINE);
        text("PLAYERS", x + 6, y + 3, SOFT);
        Gfx.rect(cx, x + 1, y + 13, w - 2, 1, PANEL_LINE);

        int listY = y + 15;
        int listH = h - 17;
        vpX = x + 1;
        vpY = listY;
        vpW = w - 2;
        vpH = listH;
        int rowW = vpW - 4;
        int rowH = 22;

        cx.enableScissor(vpX, vpY, vpX + vpW, vpY + vpH);
        if (entries.size() == 0) {
            text("NO WALKIE-TALKIES", vpX + 6, listY + 6, DIMTXT);
            text("REGISTERED YET.", vpX + 6, listY + 16, DIMTXT);
        }
        for (int i = 0; i < entries.size(); i++) {
            JsonObject e = entries.get(i).getAsJsonObject();
            int ry = listY - (int) scroll + i * rowH;
            if (ry + rowH <= listY || ry >= listY + listH) continue;
            String id = str(e, "id");
            int hy = Math.max(ry, listY);
            int hh = Math.min(ry + rowH, listY + listH) - hy;
            boolean hover = Gfx.inside(mx, my, vpX, hy, rowW, hh);
            if (id.equals(selectedId)) Gfx.rect(cx, vpX, ry, rowW, rowH - 1, 0xFF3B2A73);
            else if (hover) Gfx.rect(cx, vpX, ry, rowW, rowH - 1, 0xFF2C2158);
            spriteFor(e).draw(cx, vpX + 3, ry + 3, 1);
            text(trim(str(e, "name"), rowW - 26), vpX + 23, ry + 3, TEXT);
            text(rankLabel(e), vpX + 23, ry + 12, rankColor(e));
            hits.add(new Hit("p" + id, vpX, hy, rowW, hh, () -> select(id)));
        }
        cx.disableScissor();

        int contentH = entries.size() * rowH;
        maxScroll = Math.max(0, contentH - listH);
        if (maxScroll > 0) {
            Gfx.rect(cx, vpX + vpW - 3, listY, 2, listH, PANEL_LINE);
            int thumbH = Math.max(12, listH * listH / contentH);
            int thumbY = listY + (int) ((listH - thumbH) * (scroll / maxScroll));
            Gfx.rect(cx, vpX + vpW - 3, thumbY, 2, thumbH, SOFT);
        }
    }

    private void drawDetails(int x, int y, int w, int h) {
        Gfx.rect(cx, x, y, w, h, PANEL);
        Gfx.border(cx, x, y, w, h, PANEL_LINE);
        JsonObject e = find(selectedId);
        if (e == null) {
            text("SELECT A PLAYER FROM THE LIST.", x + 8, y + 8, DIMTXT);
            return;
        }
        String rank = str(e, "rank");
        String status = str(e, "status");

        spriteFor(e).draw(cx, x + 8, y + 8, 2);
        int tx = x + 46;
        int tw = w - 54;
        text(trim(str(e, "name"), tw), tx, y + 8, TEXT);
        text(rankLabel(e), tx, y + 19, rankColor(e));
        text(trim("GAMERTAG: " + str(e, "gamertag"), tw), tx, y + 30, DIMTXT);
        boolean online = e.has("online") && e.get("online").getAsBoolean();
        text(online ? "ONLINE" : "OFFLINE", tx, y + 41, online ? 0xFF55FF88 : DIMTXT);

        int cy = y + 54;
        if (showPass && e.has("pass")) {
            text(trim("PASSWORD: " + str(e, "pass"), w - 16), x + 8, cy, 0xFFFFD36B);
            cy += 11;
        }
        cy += 3;

        int bw = (w - 16 - 4) / 2;
        int bh = 18;
        if (resetMode && !fields.isEmpty()) {
            drawField(x + 8, cy, w - 16);
            cy += 32;
            button("set", "SET PASSWORD", x + 8, cy, bw, bh, 0xFF2D7D46, this::submit);
            button("cancel", "CANCEL", x + 8 + bw + 4, cy, bw, bh, 0xFF5A5A6A, () -> select(selectedId));
            return;
        }

        int k = 0;
        if (!rank.equals("villager")) {
            button("villager", rank.isEmpty() ? "ACCEPT: VILLAGER" : "SET: VILLAGER", slotX(x, bw, k), slotY(cy, bh, k), bw, bh, 0xFF2D7D46, () -> give("villager"));
            k++;
        }
        if (!rank.equals("william")) {
            button("william", rank.isEmpty() ? "ACCEPT: WILLIAM" : "SET: WILLIAM", slotX(x, bw, k), slotY(cy, bh, k), bw, bh, 0xFF7A3FB0, () -> give("william"));
            k++;
        }
        if (!rank.isEmpty()) {
            button("remove", "REMOVE RANK", slotX(x, bw, k), slotY(cy, bh, k), bw, bh, 0xFF9A6B1A, () -> manage("m_remove"));
            k++;
        } else if (!status.equals("rejected")) {
            button("reject", "REJECT REQUEST", slotX(x, bw, k), slotY(cy, bh, k), bw, bh, 0xFF9A3030, () -> manage("m_reject"));
            k++;
        }
        button("reset", "RESET PASSWORD", slotX(x, bw, k), slotY(cy, bh, k), bw, bh, 0xFF2F5F9A, this::startReset);
        k++;
        button("delete", confirmDelete ? "CONFIRM DELETE?" : "DELETE DATA", slotX(x, bw, k), slotY(cy, bh, k), bw, bh, 0xFF9A3030, this::deleteClick);
    }

    private static int slotX(int x, int bw, int k) {
        return x + 8 + (k % 2) * (bw + 4);
    }

    private static int slotY(int cy, int bh, int k) {
        return cy + (k / 2) * (bh + 4);
    }

    /* ------------------------------ building blocks ------------------------------ */

    private void text(String s, int x, int y, int color) {
        cx.drawText(textRenderer, s, x, y, color, false);
    }

    private String trim(String s, int maxWidth) {
        String r = s;
        while (r.length() > 1 && textRenderer.getWidth(r) > maxWidth) r = r.substring(0, r.length() - 1);
        return r;
    }

    private void button(String id, String label, int x, int y, int w, int h, int base, Runnable action) {
        boolean hover = Gfx.inside(cmx, cmy, x, y, w, h);
        int c = hover ? lighten(base, 0x28) : base;
        Gfx.rect(cx, x, y, w, h, c);
        Gfx.rect(cx, x, y, w, 1, lighten(c, 0x30));
        Gfx.rect(cx, x, y, 1, h, lighten(c, 0x30));
        Gfx.rect(cx, x, y + h - 1, w, 1, 0xFF0A0818);
        Gfx.rect(cx, x + w - 1, y, 1, h, 0xFF0A0818);
        String shown = trim(label, w - 6);
        text(shown, x + (w - textRenderer.getWidth(shown)) / 2, y + (h - 8) / 2, TEXT);
        hits.add(new Hit(id, x, y, w, h, action));
    }

    private static int lighten(int argb, int amount) {
        int r = Math.min(255, ((argb >> 16) & 0xFF) + amount);
        int g = Math.min(255, ((argb >> 8) & 0xFF) + amount);
        int b = Math.min(255, (argb & 0xFF) + amount);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void drawField(int x, int y, int w) {
        Field f = fields.get(0);
        text(f.label, x, y, SOFT);
        Gfx.rect(cx, x, y + 11, w, 14, 0xFF0C0920);
        Gfx.border(cx, x, y + 11, w, 14, 0xFF8E44AD);
        String caret = (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "";
        String vis = f.shown() + caret;
        while (vis.length() > 1 && textRenderer.getWidth(vis) > w - 8) vis = vis.substring(1);
        text(vis, x + 4, y + 14, TEXT);
        hits.add(new Hit("field", x, y + 11, w, 14, () -> active = 0));
    }

    private static String rankLabel(JsonObject e) {
        return switch (str(e, "rank")) {
            case "villager" -> "VILLAGER";
            case "william" -> "WILLIAM";
            default -> str(e, "status").equals("rejected") ? "REJECTED" : "PENDING";
        };
    }

    private static int rankColor(JsonObject e) {
        return switch (str(e, "rank")) {
            case "villager" -> 0xFF55FF55;
            case "william" -> 0xFFFF77FF;
            default -> str(e, "status").equals("rejected") ? 0xFFFF5555 : 0xFFFFFF55;
        };
    }

    private static Sprite spriteFor(JsonObject e) {
        return switch (str(e, "rank")) {
            case "villager" -> Sprite.VILLAGER;
            case "william" -> Sprite.WILLIAM;
            default -> Sprite.WALKIE;
        };
    }
}
