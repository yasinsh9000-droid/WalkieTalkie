package net.walkietalkie.client;

import net.minecraft.client.gui.DrawContext;

/** Tiny drawing helpers (everything is plain filled rectangles + text). */
final class Gfx {
    private Gfx() {}

    static void rect(DrawContext c, int x, int y, int w, int h, int argb) {
        if (w > 0 && h > 0) c.fill(x, y, x + w, y + h, argb);
    }

    static void border(DrawContext c, int x, int y, int w, int h, int argb) {
        rect(c, x, y, w, 1, argb);
        rect(c, x, y + h - 1, w, 1, argb);
        rect(c, x, y, 1, h, argb);
        rect(c, x + w - 1, y, 1, h, argb);
    }

    static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
