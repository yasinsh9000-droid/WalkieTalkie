package net.walkietalkie.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.client.gui.DrawContext;

/**
 * The walkie-talkie's own screen: a green LCD in a yellow walkie-talkie body,
 * options are lines you tap (like an old computer terminal).
 */
final class WalkieScreen extends TermScreen {
    private enum Page { WELCOME, REGISTER, LOCK, UNLOCK, STATUS, CHANGE_PASS, CHANGE_NAME, INFO }

    private static final int GREEN = 0xFF73FF8C;
    private static final int DIM = 0xFF2E9E4C;
    private static final int LINE = 0xFF1C7034;
    private static final int DARK = 0xFF03200A;
    private static final int HOVER = 0xFF4CF06A;
    private static final int RED = 0xFFFF5555;
    private static final int YELLOW = 0xFFFFFF55;
    private static final int PINK = 0xFFFF77FF;

    private Page page = Page.WELCOME;
    private JsonObject data = new JsonObject();
    private String message = "";
    private int messageColor = RED;

    // layout of the current frame
    private DrawContext cx;
    private int cmx;
    private int cmy;
    private int ix;
    private int iw;
    private int cy;
    private int ch;
    private int curY;

    WalkieScreen(JsonObject first) {
        super("Walkie-Talkie");
        apply(first);
    }

    /** A new page arrived from the server. */
    void apply(JsonObject o) {
        data = o;
        message = str(o, "msg");
        messageColor = message.endsWith("CHANGED.") ? GREEN : RED;
        switch (str(o, "page")) {
            case "welcome" -> setPage(Page.WELCOME);
            case "lock" -> setPage(message.isEmpty() ? Page.LOCK : Page.UNLOCK);
            case "status" -> setPage(Page.STATUS);
            case "info" -> setPage(Page.INFO);
            default -> {
            }
        }
    }

    private void go(Page p) {
        message = "";
        setPage(p);
    }

    private void setPage(Page p) {
        page = p;
        scroll = 0;
        fields.clear();
        active = 0;
        switch (p) {
            case REGISTER -> {
                fields.add(new Field("> YOUR NAME", false, 16, ""));
                fields.add(new Field("> PASSWORD FOR YOUR WALKIE-TALKIE", true, 16, ""));
            }
            case UNLOCK -> fields.add(new Field("> ENTER YOUR PASSWORD", true, 16, ""));
            case CHANGE_PASS -> fields.add(new Field("> NEW PASSWORD", true, 16, ""));
            case CHANGE_NAME -> fields.add(new Field("> NEW NAME", false, 16, str(data, "name")));
            default -> {
            }
        }
    }

    @Override
    protected void submit() {
        switch (page) {
            case REGISTER -> {
                String n = fields.get(0).value();
                String p = fields.get(1).value();
                String err = checkName(n);
                if (err == null) err = checkPass(p);
                if (err != null) {
                    fail(err);
                    return;
                }
                JsonObject o = action("register");
                o.addProperty("name", n);
                o.addProperty("pass", p);
                send(o);
            }
            case UNLOCK -> {
                JsonObject o = action("unlock");
                o.addProperty("pass", fields.get(0).value());
                send(o);
            }
            case CHANGE_PASS -> {
                String p = fields.get(0).value();
                String err = checkPass(p);
                if (err != null) {
                    fail(err);
                    return;
                }
                JsonObject o = action("change_pass");
                o.addProperty("value", p);
                send(o);
            }
            case CHANGE_NAME -> {
                String n = fields.get(0).value();
                String err = checkName(n);
                if (err != null) {
                    fail(err);
                    return;
                }
                JsonObject o = action("change_name");
                o.addProperty("value", n);
                send(o);
            }
            default -> {
            }
        }
    }

    private void fail(String text) {
        message = text;
        messageColor = RED;
    }

    private static String checkName(String n) {
        return n.length() < 2 || n.length() > 16 ? "NAME MUST BE 2-16 CHARACTERS." : null;
    }

    private static String checkPass(String p) {
        return p.length() < 3 || p.length() > 16 ? "PASSWORD MUST BE 3-16 CHARACTERS." : null;
    }

    /* ------------------------------ drawing ------------------------------ */

    @Override
    protected void drawScreen(DrawContext ctx, int mx, int my) {
        cx = ctx;
        cmx = mx;
        cmy = my;
        ctx.fill(0, 0, width, height, 0xB0000000);

        int dw = Math.min(width - 10, 440);
        int dh = Math.min(height - 8, 236);
        int dx = (width - dw) / 2;
        int dy = (height - dh) / 2;

        // the yellow walkie-talkie body with its dark bezel
        Gfx.rect(ctx, dx, dy, dw, dh, 0xFF0C0C0C);
        Gfx.rect(ctx, dx + 1, dy + 1, dw - 2, dh - 2, 0xFFE2AB1C);
        Gfx.rect(ctx, dx + 5, dy + 5, dw - 10, dh - 10, 0xFF785408);
        Gfx.rect(ctx, dx + 6, dy + 6, dw - 12, dh - 12, 0xFF1A1A1C);
        Gfx.rect(ctx, dx + 12, dy + 12, dw - 24, dh - 24, 0xFF3A3A3E);

        // the green LCD
        int lx = dx + 13;
        int ly = dy + 13;
        int lw = dw - 26;
        int lh = dh - 26;
        ctx.fillGradient(lx, ly, lx + lw, ly + lh, 0xFF0E3218, 0xFF041209);
        for (int yy = ly + 2; yy < ly + lh; yy += 3) {
            ctx.fill(lx, yy, lx + lw, yy + 1, 0x22000000);
        }

        ix = lx + 7;
        iw = lw - 14;
        int top = ly + 5;

        // header: title + [X]
        text("WALKIE-OS v1.0", ix + 2, top + 2, GREEN);
        int closeW = textRenderer.getWidth("[X]") + 6;
        int closeX = ix + iw - closeW;
        boolean closeHover = Gfx.inside(mx, my, closeX, top, closeW, 13);
        if (closeHover) Gfx.rect(ctx, closeX, top, closeW, 13, HOVER);
        text("[X]", closeX + 3, top + 2, closeHover ? DARK : GREEN);
        hits.add(new Hit("close", closeX, top, closeW, 13, this::close));
        Gfx.rect(ctx, ix, top + 14, iw, 1, LINE);

        // footer
        int footerY = ly + lh - 13;
        text("> TAP AN OPTION     [X] = CLOSE", ix + 2, footerY, DIM);

        // content (scrollable)
        cy = top + 18;
        ch = footerY - 3 - cy;
        vpX = ix;
        vpY = cy;
        vpW = iw;
        vpH = ch;
        ctx.enableScissor(ix, cy, ix + iw, cy + ch);
        curY = cy - (int) scroll;
        drawPage();
        int contentH = curY - (cy - (int) scroll);
        ctx.disableScissor();
        maxScroll = Math.max(0, contentH - ch);

        if (maxScroll > 0) {
            Gfx.rect(ctx, ix + iw - 3, cy, 2, ch, LINE);
            int thumbH = Math.max(12, ch * ch / contentH);
            int thumbY = cy + (int) ((ch - thumbH) * (scroll / maxScroll));
            Gfx.rect(ctx, ix + iw - 3, thumbY, 2, thumbH, GREEN);
        }
    }

    private void drawPage() {
        switch (page) {
            case WELCOME -> {
                rule();
                line("NO PROFILE FOUND.", GREEN);
                line("REGISTER THIS WALKIE-TALKIE", GREEN);
                line("TO REQUEST A RANK.", GREEN);
                rule();
                gap(4);
                row("register", "> REGISTER", null, Sprite.WALKIE, () -> go(Page.REGISTER));
                row("exit", "> EXIT", null, null, this::close);
            }
            case REGISTER -> {
                rule();
                line("NEW PROFILE", GREEN);
                rule();
                messageLine();
                field(0);
                field(1);
                gap(2);
                row("submit", "> SUBMIT", null, null, this::submit);
                row("back", "> BACK", null, null, () -> go(Page.WELCOME));
            }
            case LOCK -> {
                rule();
                line("STATUS : LOCKED", GREEN);
                line("ENTER YOUR PASSWORD TO", GREEN);
                line("CONTINUE.", GREEN);
                rule();
                gap(4);
                row("enter", "> ENTER PASSWORD", null, Sprite.WALKIE, () -> go(Page.UNLOCK));
                row("exit", "> EXIT", null, null, this::close);
            }
            case UNLOCK -> {
                rule();
                line("STATUS : LOCKED", GREEN);
                rule();
                messageLine();
                field(0);
                gap(2);
                row("unlock", "> UNLOCK", null, null, this::submit);
                row("back", "> BACK", null, null, () -> go(Page.LOCK));
            }
            case STATUS -> drawStatus();
            case CHANGE_PASS, CHANGE_NAME -> {
                rule();
                line(page == Page.CHANGE_PASS ? "CHANGE PASSWORD" : "CHANGE NAME", GREEN);
                rule();
                messageLine();
                field(0);
                gap(2);
                row("save", "> SAVE", null, null, this::submit);
                row("back", "> BACK", null, null, () -> go(Page.STATUS));
            }
            case INFO -> {
                rule();
                JsonArray lines = data.has("lines") ? data.getAsJsonArray("lines") : new JsonArray();
                for (int i = 0; i < lines.size(); i++) line(lines.get(i).getAsString(), GREEN);
                rule();
                gap(4);
                row("ok", "> OK", null, null, this::close);
            }
        }
    }

    private void drawStatus() {
        String rank = str(data, "rank");
        String status = str(data, "status");
        rule();
        line("NAME : " + str(data, "name"), GREEN);
        line("RANK : " + rankLabel(rank, status), rankColor(rank, status));
        rule();
        messageLine();
        gap(4);
        if (!rank.isEmpty()) {
            row("refresh", "> RANK: " + rankLabel(rank, status), "TAP TO REFRESH", spriteFor(rank), () -> send(action("status")));
        } else {
            row("refresh", "> STATUS: " + rankLabel(rank, status), "WAITING FOR A MANAGER", Sprite.WALKIE, () -> send(action("status")));
        }
        row("cpass", "> CHANGE PASSWORD", null, null, () -> go(Page.CHANGE_PASS));
        row("cname", "> CHANGE NAME", null, null, () -> go(Page.CHANGE_NAME));
        if (rank.isEmpty() && status.equals("rejected")) {
            row("resend", "> SEND REQUEST AGAIN", null, null, () -> send(action("resend")));
        }
        row("exit", "> EXIT", null, null, this::close);
    }

    private static String rankLabel(String rank, String status) {
        return switch (rank) {
            case "villager" -> "VILLAGER";
            case "william" -> "WILLIAM";
            default -> status.equals("rejected") ? "REJECTED" : "PENDING";
        };
    }

    private static int rankColor(String rank, String status) {
        return switch (rank) {
            case "villager" -> 0xFF55FF55;
            case "william" -> PINK;
            default -> status.equals("rejected") ? RED : YELLOW;
        };
    }

    private static Sprite spriteFor(String rank) {
        return rank.equals("william") ? Sprite.WILLIAM : Sprite.VILLAGER;
    }

    /* ------------------------------ building blocks ------------------------------ */

    private void text(String s, int x, int y, int color) {
        cx.drawText(textRenderer, s, x, y, color, false);
    }

    private void line(String s, int color) {
        if (curY + 10 > cy && curY < cy + ch) text(s, ix + 2, curY, color);
        curY += 10;
    }

    private void rule() {
        line("--------------------------", LINE);
    }

    private void gap(int h) {
        curY += h;
    }

    private void messageLine() {
        if (!message.isEmpty()) {
            line(message, messageColor);
            gap(3);
        }
    }

    private void row(String id, String label, String sub, Sprite icon, Runnable action) {
        int h = sub == null ? 18 : 26;
        int y = curY;
        curY += h;
        if (y + h <= cy || y >= cy + ch) return;
        int hy = Math.max(y, cy);
        int hh = Math.min(y + h, cy + ch) - hy;
        boolean hover = Gfx.inside(cmx, cmy, ix, hy, iw, hh);
        if (hover) Gfx.rect(cx, ix, y, iw, h, HOVER);
        text(label, ix + 6, y + (sub == null ? 5 : 4), hover ? DARK : GREEN);
        if (sub != null) text(sub, ix + 6, y + 14, hover ? DARK : DIM);
        if (icon != null) icon.draw(cx, ix + iw - 22, y + (h - icon.h) / 2, 1);
        Gfx.rect(cx, ix, y + h - 1, iw, 1, LINE);
        hits.add(new Hit(id, ix, hy, iw, hh, action));
    }

    private void field(int i) {
        Field f = fields.get(i);
        int y = curY;
        curY += 30;
        if (y + 30 <= cy || y >= cy + ch) return;
        text(f.label, ix + 2, y + 1, GREEN);
        boolean act = i == active;
        int bx = ix + 2;
        int by = y + 12;
        int bw = iw - 8;
        Gfx.rect(cx, bx, by, bw, 14, 0xFF021208);
        Gfx.border(cx, bx, by, bw, 14, act ? GREEN : DIM);
        String caret = act && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "";
        String vis = f.shown() + caret;
        while (vis.length() > 1 && textRenderer.getWidth(vis) > bw - 8) vis = vis.substring(1);
        text(vis, bx + 4, by + 3, GREEN);
        int hy = Math.max(by, cy);
        int hh = Math.min(by + 14, cy + ch) - hy;
        hits.add(new Hit("field" + i, bx, hy, bw, Math.max(hh, 1), () -> active = i));
    }
}
