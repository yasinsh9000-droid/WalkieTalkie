package net.walkietalkie;

import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

public enum Rank {
    VILLAGER("villager", "Villager", "wt_villager", Formatting.GREEN, "\uE201"),
    WILLIAM("william", "William", "wt_william", Formatting.DARK_PURPLE, "\uE200");

    public final String key;
    public final String label;
    /** Used both as the command tag and as the scoreboard team name. */
    public final String tag;
    public final Formatting color;
    public final String glyph;

    Rank(String key, String label, String tag, Formatting color, String glyph) {
        this.key = key;
        this.label = label;
        this.tag = tag;
        this.color = color;
        this.glyph = glyph;
    }

    public static Rank of(String key) {
        for (Rank r : values()) {
            if (r.key.equals(key)) return r;
        }
        return null;
    }

    /** "[icon] [William] " shown before the player's name (name tag, tab list, chat). */
    public Text prefix() {
        MutableText icon = Text.literal(glyph).setStyle(
                Style.EMPTY.withFont(Identifier.of(WalkieTalkieMod.MOD_ID, "icons")).withColor(Formatting.WHITE));
        MutableText name = Text.literal(" [" + label + "] ").formatted(color);
        return Text.empty().append(icon).append(name);
    }
}
