package net.walkietalkie;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

/** Tiny config file: config/walkie_talkie.json */
public final class WalkieConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** true = managers can read players' passwords. */
    public static boolean showPasswordToManager = false;
    public static int nameMin = 2;
    public static int nameMax = 16;
    public static int passMin = 3;
    public static int passMax = 16;
    public static int maxPasswordTries = 5;

    private static final class Data {
        boolean showPasswordToManager = false;
        int nameMin = 2;
        int nameMax = 16;
        int passMin = 3;
        int passMax = 16;
        int maxPasswordTries = 5;
    }

    private WalkieConfig() {}

    public static void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("walkie_talkie.json");
        try {
            Data d = new Data();
            if (Files.exists(file)) {
                Data loaded = GSON.fromJson(Files.readString(file), Data.class);
                if (loaded != null) d = loaded;
            }
            showPasswordToManager = d.showPasswordToManager;
            nameMin = d.nameMin;
            nameMax = d.nameMax;
            passMin = d.passMin;
            passMax = d.passMax;
            maxPasswordTries = d.maxPasswordTries;
            Files.writeString(file, GSON.toJson(d));
        } catch (Exception e) {
            WalkieTalkieMod.LOGGER.warn("Could not read/write walkie_talkie.json config: {}", e.toString());
        }
    }
}
