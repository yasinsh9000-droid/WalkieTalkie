package net.walkietalkie;

import java.util.function.Function;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public final class ModItems {
    public static final Item WALKIE_TALKIE = register("walkie_talkie", WalkieItem::new, new Item.Settings().maxCount(1));
    public static final Item MANAGER_CARD = register("manager_card", ManagerCardItem::new, new Item.Settings().maxCount(1));

    private ModItems() {}

    private static Item register(String name, Function<Item.Settings, Item> factory, Item.Settings settings) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(WalkieTalkieMod.MOD_ID, name));
        Item item = factory.apply(settings.registryKey(key));
        return Registry.register(Registries.ITEM, key, item);
    }

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(WALKIE_TALKIE);
            entries.add(MANAGER_CARD);
        });
    }
}
