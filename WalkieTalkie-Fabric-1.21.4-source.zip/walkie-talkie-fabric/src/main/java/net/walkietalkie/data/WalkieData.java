package net.walkietalkie.data;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public class WalkieData {
    public Map<String, Entry> entries = new LinkedHashMap<>();
    public Set<String> managers = new LinkedHashSet<>();
}
