package net.walkietalkie.data;

/** One registered walkie-talkie. Stored in the world folder (walkie_talkie.json). */
public class Entry {
    public String id = "";
    public String gamertag = "";
    public String name = "";
    public String pass = "";
    /** "pending", "approved" or "rejected". */
    public String status = "pending";
    /** "", "villager" or "william". */
    public String rank = "";
}
